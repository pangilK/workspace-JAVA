package member;

public class JavaApplication {

	public static void main(String[] args) {
		new MemberManagement();
	}

}
